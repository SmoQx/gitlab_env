import pytest
import sqlite3
import PasswordMGR


DB_FILENAME = "password_manager.db"


def test_load_key(run=False):
    if run:
        assert PasswordMGR.load_key() != None
    else:
        pass


def set_key():
    key = b"N1vefi2000T3CbIvyIS-wGXdpKszQiTvji7-7zkBHbA="
    with open("secret.key", "wb") as key_file:
        key_file.write(key)


def test_passwd_gen():
    passwd = "401b09eab3c013d4ca54922bb802bec8fd5318192b0a75f201d8b3727429080fb337591abd3e44453b954555b7a0812e1081c39b740293f765eae731f5a65ed1"
    assert PasswordMGR.hash_master_password("asdf") == passwd


def test_encrypt():
    password = "asdf"
    encypted_password = PasswordMGR.encrypt_password(password)
    decrypted_password = PasswordMGR.decrypt_password(encypted_password)
    assert password != encypted_password
    assert decrypted_password == password


def test_decrypt():
    set_key()   
    hashed = "gAAAAABoDAbk_1W8c3ZkJhsVPdKOO0NR1hg125OMBoaeAo0PF3PAFqeGpuWq0YJ6LRlOsk2B-b80HDZ6TgGOid8yLMh2SnIKmA=="
    hashed_2 = "gAAAAABoFkZged4EhAJFTJvaHRMlIzHdQjPmgwuAlIUgbbSrd4QoQUCYVQ2yBMZLLXiM9FVjew-YSNvkSz-mPsy9E6He-PZ56g=="
    assert PasswordMGR.decrypt_password(hashed_2) == "asdf"
    assert PasswordMGR.decrypt_password(hashed) == "asdf"


def test_init_db():
    with sqlite3.connect(DB_FILENAME) as conn:
        cursor = conn.cursor()
        cursor.execute("""SELECT name FROM sqlite_master where type='table';""")
        tables = {row[0] for row in cursor.fetchall()}
        expected_tables = {"passwords", "master_password"}

    assert expected_tables.issubset(tables)


if __name__ == "__main__":
    print(PasswordMGR.encrypt_password("asdf"))
