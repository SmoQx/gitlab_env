def main(number: int):
    if type(number) != int:
        raise TypeError("should be a int")
    return number + 2
    

if __name__ == "__main__":
    main(10)
