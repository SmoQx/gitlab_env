"""
CustomTkinter Listbox
Author: Akash Bora (Akascape)
License: MIT
Homepage: https://github.com/Akascape/CTkListbox
"""

__version__ = '1.4'

from .ctk_listbox import CTkListbox
